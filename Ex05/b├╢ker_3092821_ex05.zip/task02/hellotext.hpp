#ifndef HELLOTEXT_H
#define HELLOTEXT_H

class Hellotext {
    public:
        Hellotext();
        ~Hellotext();
}; 

#endif